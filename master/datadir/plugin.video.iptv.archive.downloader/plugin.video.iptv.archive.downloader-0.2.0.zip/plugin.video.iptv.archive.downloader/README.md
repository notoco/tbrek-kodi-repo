# IPTV Archive Downloader
## plugin.video.iptv.archive.downloader

Kodi addon for downloading streams from the IPTV Simple Client archive

This addon is an easily extensible python addon that should work with any device.

You will need a version of ffmpeg for your device. 

https://ffmpeg.org/

Android builds are here: https://github.com/WritingMinds/ffmpeg-android/releases/latest

On Android this addon will copy ffmpeg to the /data/data folder so it can run.

